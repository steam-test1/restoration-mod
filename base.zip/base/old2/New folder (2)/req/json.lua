_G.json = {}

function json.decode( data )

	value = json09.decode( data )
	return value

end

function json.encode( data )
	return json10.encode( data )
end